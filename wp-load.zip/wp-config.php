<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'store' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ';db/iknd;Cm]UNrK9$Y6bS.(b+!g#h7_V%y^xs@L5jsLY0icu$V#oQQ5kA49m<ra' );
define( 'SECURE_AUTH_KEY',  '|B`@=U06$~P4k=zp)*HNm2xl-vcjPX!&,W]KpIV%E:7G}%+8qH68&C<J&vBxe.?,' );
define( 'LOGGED_IN_KEY',    '?5AL5/e0rVmly*+^8?iEIV%_NL_|^Td?OeB=-EDc4HW{{B)=)b4VvXHJ@1Bp0y~&' );
define( 'NONCE_KEY',        'bV:n$-zbV+WVT2a2#ww7@Oh]zD}UdD{W2%sgH&)$]1Wy<g8cEnihWBVh^}Kf4&Bd' );
define( 'AUTH_SALT',        'b>61lO*PJDPW<5V8#yD0R(A=>w |33 TG$HH~U~z[c}{JEvr*h?:yPd.9c!EHmC~' );
define( 'SECURE_AUTH_SALT', '1*@~B;xK?~`zLlW*^`FL!#zcp$/2yW*s&,p[2HT;]!4A+7InPY)^jI9|$V&Zp(-!' );
define( 'LOGGED_IN_SALT',   '2hzTib+Ajai2mkgfnX`aM{)Npgez8#2{gc^MWH*~g!P#vN>Ai.}Ja/<ukX*I1vP=' );
define( 'NONCE_SALT',       's+a*wRJ)DES-fvdcL_`*AYN2QQlbfhCGG4.tG+58Nqv0bcPr8<1)$Qfr/{N;X_kp' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
